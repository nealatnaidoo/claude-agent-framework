# Lessons Playbook (v2.0)
- Classify each lesson: architecture / determinism / typing / tooling / ops.
- Convert into: (a) checklist item, (b) gate check, (c) prompt constraint.
- Validate by running the golden-brief prompt tests and a small coding kata.
